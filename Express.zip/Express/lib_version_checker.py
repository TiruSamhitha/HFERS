import keras
import tensorflow
import PyQt5

print(keras.__version__)
print(tensorflow.__version__)