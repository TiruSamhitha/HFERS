import os
os.system("powershell -c out.jpg")