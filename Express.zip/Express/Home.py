# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'E:\QT\home.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from webcam import WebCamDetection
from ImageUpload import ImageUpload

import sys

class Home(object):

    def webcamdef(self):
        try:
            self.showAlertBox("Information", "Launching Web Cam\nPress ' q ' to Stop the Expression Recognition System ")
            WebCamDetection.process()

        except Exception as e:

            print("Error=" + e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)
            print(e)

    def uploadpic(self):
        try:
            self.Dialog2 = QtWidgets.QDialog()
            self.ui2 = ImageUpload()
            self.ui2.setupUi(self.Dialog2)
            self.Dialog2.show()

        except Exception as e:
            print("Error=" + e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)
            print(e)

    def showAlertBox(self, title, message):
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Information)
        msgBox.setWindowTitle(title)
        msgBox.setText(message)
        msgBox.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msgBox.exec_()

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1348, 843)
        # Dialog.setStyleSheet("background-color: rgb(172, 116, 254);")
        Dialog.setStyleSheet("background-image: url(background_image_2.jpg);")
        self.verticalLayout = QtWidgets.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName("verticalLayout")
        self.tabWidget = QtWidgets.QTabWidget(Dialog)
        self.tabWidget.setObjectName("tabWidget")
        self.tab = QtWidgets.QWidget()
        self.tab.setObjectName("tab")
        self.label = QtWidgets.QLabel(self.tab)
        self.label.setGeometry(QtCore.QRect(70, 250, 500, 111))
        self.label.setStyleSheet("background-image: none; font: 18pt \"Century Gothic\";\n"
"color: rgb(255, 255, 255);")
        self.label.setObjectName("label")
        self.uploadimage = QtWidgets.QPushButton(self.tab)
        self.uploadimage.setGeometry(QtCore.QRect(120, 400, 140, 150))
        self.uploadimage.setStyleSheet("background-image: none; image: url(Images-icon.png);")
        self.uploadimage.setText("")
        self.uploadimage.setObjectName("uploadimage")
        #####################
        self.uploadimage.clicked.connect(self.uploadpic)
        #####################

        self.webcam = QtWidgets.QPushButton(self.tab)
        self.webcam.setGeometry(QtCore.QRect(348, 400, 140, 150))
        self.webcam.setStyleSheet("background-image: none; image: url(e502608e8b.png);")
        self.webcam.setText("")
        self.webcam.setObjectName("webcam")

        #####################
        self.webcam.clicked.connect(self.webcamdef)
        #####################


        self.tabWidget.addTab(self.tab, "")
        self.verticalLayout.addWidget(self.tabWidget)

        self.retranslateUi(Dialog)
        self.tabWidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label.setText(_translate("Dialog", "<html><head/><body><p align=\"center\">Human Face and Expression </p><p align=\"center\">Recognition System</p></body></html>"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), _translate("Dialog", "Home"))



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Home()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

